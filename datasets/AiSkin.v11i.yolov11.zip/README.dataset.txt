# AiSkin > 2025-01-19 12:07pm
https://universe.roboflow.com/aicare4u/aiskin

Provided by a Roboflow user
License: CC BY 4.0

